EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr User 30000 22000
encoding utf-8
Sheet 1 1
Title "TrackLab Electronics - TrackLab_etage1"
Date "2026-11-15"
Rev "5"
Comp ""
Comment1 "Schema genere depuis generer_netlist.py - connexions par etiquettes de reseau"
Comment2 ""
Comment3 ""
Comment4 ""
$EndDescr
$Comp
L TL:J1 J1
U 1 1 152F8F46
P 3300 2850
F 0 "J1" H 3300 1600 60 0000 C CNN
F 1 "ESP32-S3-DevKitC-1 rangée J1" H 3300 4100 60 0000 C CNN
F 2 "Connector_PinSocket_2.54mm:PinSocket_1x22_P2.54mm_Vertical" H 3300 2850 50 0001 C CNN
F 3 "~" H 3300 2850 50 0001 C CNN
	1    3300 2850
	1    0    0    -1
$EndComp
Text Label 2500 1950 2 60 ~ 0
+3V3
Text Label 2500 2150 2 60 ~ 0
+3V3
Text Label 2500 2350 2 60 ~ 0
CAN_RX
Text Label 2500 2550 2 60 ~ 0
CAN_TX
Text Label 2500 2750 2 60 ~ 0
GPS_TX
Text Label 2500 2950 2 60 ~ 0
ENT1
Text Label 2500 3150 2 60 ~ 0
BTN_REC
Text Label 2500 3350 2 60 ~ 0
GPS_RX
Text Label 2500 3550 2 60 ~ 0
LED_B
Text Label 2500 3750 2 60 ~ 0
LED_R
Text Label 4100 1950 0 60 ~ 0
ENT2
Text Label 4100 2150 0 60 ~ 0
ADC3
Text Label 4100 2350 0 60 ~ 0
ENT3
Text Label 4100 2550 0 60 ~ 0
SD_CS
Text Label 4100 2750 0 60 ~ 0
SD_MOSI
Text Label 4100 2950 0 60 ~ 0
SD_SCK
Text Label 4100 3150 0 60 ~ 0
SD_MISO
Text Label 4100 3350 0 60 ~ 0
ENT4
Text Label 4100 3550 0 60 ~ 0
+5V
Text Label 4100 3750 0 60 ~ 0
GND
$Comp
L TL:J3 J3
U 1 1 5C9D5824
P 6900 2450
F 0 "J3" H 6900 1600 60 0000 C CNN
F 1 "ESP32-S3-DevKitC-1 rangée J3" H 6900 3300 60 0000 C CNN
F 2 "Connector_PinSocket_2.54mm:PinSocket_1x22_P2.54mm_Vertical" H 6900 2450 50 0001 C CNN
F 3 "~" H 6900 2450 50 0001 C CNN
	1    6900 2450
	1    0    0    -1
$EndComp
Text Label 6100 1950 2 60 ~ 0
GND
Text Label 6100 2150 2 60 ~ 0
ADC1
Text Label 6100 2350 2 60 ~ 0
ADC2
Text Label 6100 2550 2 60 ~ 0
ENT7
Text Label 6100 2750 2 60 ~ 0
ENT6
Text Label 6100 2950 2 60 ~ 0
ENT5
Text Label 7700 1950 0 60 ~ 0
OUT2
Text Label 7700 2150 0 60 ~ 0
OUT1
Text Label 7700 2350 0 60 ~ 0
ENT8
Text Label 7700 2550 0 60 ~ 0
LED_G
Text Label 7700 2750 0 60 ~ 0
GND
Text Label 7700 2950 0 60 ~ 0
GND
$Comp
L TL:J_STACK J_STACK
U 1 1 2C869ACC
P 10500 3450
F 0 "J_STACK" H 10500 1600 60 0000 C CNN
F 1 "Support 2x16 vers étage 2" H 10500 5300 60 0000 C CNN
F 2 "Connector_PinSocket_2.54mm:PinSocket_2x16_P2.54mm_Vertical" H 10500 3450 50 0001 C CNN
F 3 "~" H 10500 3450 50 0001 C CNN
	1    10500 3450
	1    0    0    -1
$EndComp
Text Label 9700 1950 2 60 ~ 0
+5V
Text Label 9700 2150 2 60 ~ 0
+5V
Text Label 9700 2350 2 60 ~ 0
GND
Text Label 9700 2550 2 60 ~ 0
GND
Text Label 9700 2750 2 60 ~ 0
+3V3
Text Label 9700 2950 2 60 ~ 0
+3V3
Text Label 9700 3150 2 60 ~ 0
CAN_TX
Text Label 9700 3350 2 60 ~ 0
CAN_RX
Text Label 9700 3550 2 60 ~ 0
GPS_RX
Text Label 9700 3750 2 60 ~ 0
GPS_TX
Text Label 9700 3950 2 60 ~ 0
SD_CS
Text Label 9700 4150 2 60 ~ 0
SD_MOSI
Text Label 9700 4350 2 60 ~ 0
SD_SCK
Text Label 9700 4550 2 60 ~ 0
SD_MISO
Text Label 9700 4750 2 60 ~ 0
ENT1
Text Label 9700 4950 2 60 ~ 0
ENT2
Text Label 11300 1950 0 60 ~ 0
ENT3
Text Label 11300 2150 0 60 ~ 0
ENT4
Text Label 11300 2350 0 60 ~ 0
ENT5
Text Label 11300 2550 0 60 ~ 0
ENT6
Text Label 11300 2750 0 60 ~ 0
ENT7
Text Label 11300 2950 0 60 ~ 0
ENT8
Text Label 11300 3150 0 60 ~ 0
ADC1
Text Label 11300 3350 0 60 ~ 0
ADC2
Text Label 11300 3550 0 60 ~ 0
ADC3
Text Label 11300 3750 0 60 ~ 0
BTN_REC
Text Label 11300 3950 0 60 ~ 0
OUT1
Text Label 11300 4150 0 60 ~ 0
OUT2
Text Label 11300 4350 0 60 ~ 0
LED_G
Text Label 11300 4550 0 60 ~ 0
LED_R
Text Label 11300 4750 0 60 ~ 0
LED_B
Text Label 11300 4950 0 60 ~ 0
GND
$EndSCHEMATC
