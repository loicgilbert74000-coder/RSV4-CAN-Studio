update=22/05/2015 07:44:53
version=1
last_client=kicad
[eeschema]
version=1
LibDir=
[eeschema/libraries]
LibName1=TL
